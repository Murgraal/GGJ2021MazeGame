﻿internal interface IObservable
{
}